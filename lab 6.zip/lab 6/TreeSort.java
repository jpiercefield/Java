import bst.*;
import ki.KeyedItem;

public class TreeSort {
	public static KeyedItem[] treeSort(KeyedItem[] unsorted) {
		int n = unsorted.length;
		Class cls = unsorted.getClass().getComponentType();
      KeyedItem[] sorted = (KeyedItem[]) java.lang.reflect.Array.newInstance(cls, n);
		
		for (int i = 0; i < n; i++)
         sorted[i] = unsorted[i];
     
		return treeSort(sorted, n);
	}
	public static KeyedItem[] treeSort(KeyedItem[] unsorted, int n) {
		BinarySearchTree bst = new BinarySearchTree(true, true);
		
		for (int i = 0; i < n; i++) {
			bst.insert(unsorted[i]);
		}
		
		TreeIterator iter = bst.iterator();
		iter.setInorder();
		
		int i = 0;
		while(iter.hasNext()) {
			unsorted[i] = (KeyedItem) iter.next();
			i++;
		}
		
		return unsorted;
	}
}
