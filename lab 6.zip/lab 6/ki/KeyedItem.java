package ki;
public abstract class KeyedItem
{
    // instance variables - replace the example below with your own
    private Comparable key;
    
    public KeyedItem(Comparable key)
    {
        this.key = key;
        
    }    

   
    public Comparable getKey()
    {
        // put your code here
        return this.key;
    }
    
    public String toString()
    {
        return key.toString();
    }
}
