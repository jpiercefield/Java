import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class AVLDriver
{
   public static void main(String[] args)
   {
      //call the height and isBalanced methods and display the results with all items inserted
      CD[] cds = readMusic("cds.txt");
      AVLTree tree = new AVLTree();
      for (int i = 0; i < cds.length; i++) {
         tree.insert(cds[i]);
      }
      printInfo(tree, "All CDs should be added.");
      
      for (int i = 10; i < 20; i++) {
         tree.delete(cds[i].getKey());
      }
      printInfo(tree, "Size should be 10 less than original size."); // size should be 10 less than original
      
      for (int i = 0; i < 3; i++) {
         try {
            tree.insert(cds[i]); // should throw exception - Duplicate
         } catch (TreeException e) {
            System.out.println(e.toString());
         }
      }
      printInfo(tree, "Duplicate Items should have been found and thrown 3 exceptions"); // should be no changes
      
      CD cd = new CD("Ghost Opera", "Kamelot", 2007, 5, 11);
      try {
         tree.delete(cd.getKey());
      } catch (TreeException e) {
         System.out.println(e.toString());
      }
      tree.retrieve(cd.getKey());
      printInfo(tree, "Item not found TreeException should have been thrown, and no changes should have occurred."); // no changes
      
      
   }
   
   private static void printInfo(BinarySearchTree tree, String message) {
      System.out.println();
      System.out.println("================================================");
      System.out.println();
      displayTree(tree);
      System.out.println();
      System.out.println("Size: " + tree.size());
      System.out.println("Height: " + tree.height());
      System.out.println("Balanced: " + (tree.isBalanced() ? "true" : "false"));
      System.out.println();
      System.out.println(message);
      System.out.println();
      pauseOutput();
      System.out.println("================================================");
      System.out.println();
   }
   
   private static void pauseOutput() {
      Scanner in = new Scanner(System.in);
      System.out.print("Press <Enter> to continue...");
      in.nextLine();
   }
   
   private static void displayTree(BinarySearchTree tree) {
      TreeIterator iter = tree.iterator();
      iter.setInorder();
      while (iter.hasNext()) {
         System.out.println(iter.next().toString());
      }
   }

   private static CD[] readMusic(String fileName)
   {
      FileIO file = new FileIO(fileName, FileIO.FOR_READING);
      String str = file.readLine();
      ArrayList<CD> cds = new ArrayList<CD>();
      while (!file.EOF())
      {
         String title = file.readLine();
         int year = Integer.parseInt(file.readLine());
         int rating = Integer.parseInt(file.readLine());
         int numTracks = Integer.parseInt(file.readLine());
         CD cd = new CD(title, str, year, rating, numTracks);

         cds.add(cd);
         int tracks = 1;

         while (tracks <= numTracks)
         {
            String temp = file.readLine();
            String[] line = temp.split(",");
            String len = line[0];
            String songTitle = line[1];
            cd.addSong(songTitle, len);
            tracks++;
         }

         str = file.readLine();
      }

      CD[] cds_array = new CD[cds.size()];
      int i = 0;
      for(CD cd : cds)
      {
         cds_array[i] = cds.get(i);
         i++;
      }
      return cds_array;
   }
}