public class Craps {
   public static void main(String args[]){
      double finalNum = (double)playCraps(752);
      System.out.println("Percentage of 2, 3, or 12's = %" + ((finalNum/752)*100));
   }
   
   public static int playCraps(int numberOfRolls){
      CrapsDice dice = new CrapsDice();
      int amount = 0;
      for(int i=0;i<numberOfRolls;i++){
         int num = dice.roll();
         if(num == 2 || num==3 || num==12)
         {
            amount++;
         }
      
      }
      return amount;
   
   
   
   }
   
   
}
      
      
      