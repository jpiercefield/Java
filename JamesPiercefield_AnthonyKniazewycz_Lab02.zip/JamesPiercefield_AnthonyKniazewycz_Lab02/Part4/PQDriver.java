import java.util.PriorityQueue;

public class PQDriver
{
	public static void main (String[] args)
	{
		PriorityQueue<CD> myCDs = new PriorityQueue<CD>();
		insertCD(myCDs, createCD("The Gallery", "Dark Tranquillity")); 
		insertCD(myCDs, createCD("Since the Day It All Came Down", "Insomnium")); 
		insertCD(myCDs, createCD("If Emotions Still Burn", "Ablaze My Sorrow")); 
		insertCD(myCDs, createCD("Swamplord", "Kalmah")); 
		insertCD(myCDs, createCD("Towards the Twilight", "Night in Gales")); 
		insertCD(myCDs, createCD("An Epic Defiance", "Detonation")); 
		insertCD(myCDs, createCD("From Your Grave", "The Absence")); 
		insertCD(myCDs, createCD("Inhumanity", "Mors Principium Est")); 
		insertCD(myCDs, new CD("The Gallery", "Dark Tranquillity", 13.99, 11)); //a "duplicate" with a different value and tracks 
		insertCD(myCDs, createCD("Timeless Departure", "Skyfire")); 
		insertCD(myCDs, createCD("Spirits and August Light", "Omnium Gatherum")); 
		insertCD(myCDs, createCD("Slaughter of the Soul", "At the Gates")); 
		insertCD(myCDs, createCD("Shadows and Dust", "Kataklysm")); 
		insertCD(myCDs, createCD("Fate of Norns", "Amon Amarth")); 
		insertCD(myCDs, createCD("Corroding From Inside", "Searing Meadow")); 
		insertCD(myCDs, createCD("The Glorious Burden", "Iced Earth")); 
		insertCD(myCDs, createCD("Stained", "Imperanon")); 
		insertCD(myCDs, createCD("As Night Conquers Day", "Autumn Leaves"));
		CD pulledCD = myCDs.poll();
		while (pulledCD != null)
		{
			System.out.println(pulledCD.toString());
			pulledCD = myCDs.poll();
		}

	}
	public static CD createCD(String title, String artist)
	{
		return new CD(title, artist, 14.99, 10);
	}
	public static void insertCD(PriorityQueue pq, CD cd)
	{
		pq.offer(cd);
	}
}