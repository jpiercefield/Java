//James Piercefield
import java.util.Scanner;
public class PasswordDriver{

   public static void main(String[] args){
   
      Scanner Uinput = new Scanner(System.in);
      String word;
      Password myPass = new Password();
      int num = 0;
      int amount = 0;
      while(num == 0)
      {
         String words;
         word = Keyboard.readString("Enter a string: ");
         String newString = "q";

         if(word.equals(newString)){
            num = 1;
         }
         addWords(myPass, word);
         amount++; 
      }
      guessWords(myPass);
      
      return;
      //String guess;
      //System.out.println("Enter a guess: ");
      //guess = Uinput.next();
   }
   
   public static void addWords(Password myPass, String word){
      myPass.addWord(word);
      
   }
   
   public static void guessWords(Password myPass){
       int alpha, guess, myNum;
       int guesses = 0;
       String beta;
       Boolean win = false;
       do{
       alpha = myPass.bestGuess();
       beta = myPass.getOriginalWord(alpha);
       System.out.println("You should guess: " + beta);
       //System.out.println("Index of word to guess (1-based, from orginal list): " + alpha);
       guess = Keyboard.readInt("Index of word to guess (1-based, from orginal list): ");
       myNum = Keyboard.readInt("Number of character matches: ");
       myPass.guess(guess, myNum);
       System.out.println("\n" + myPass.toString());
       if(myPass.getNumberOfPasswordsLeft() == 1)
           win = true;
       else
           guesses++;
       }while(win == false || guesses >= 4);
        return;
        
        
   }

}