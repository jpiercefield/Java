public enum MenuCategory
{
    MAIN, DESSERT, SIDE, DRINK
}
