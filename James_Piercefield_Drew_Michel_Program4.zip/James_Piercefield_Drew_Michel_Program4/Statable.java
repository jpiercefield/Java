public interface Statable {
    public String getState();
}