/** BinarySearchTree class cretes binary search trees that follow the binary tree property.
   David Head
   James Piercefield
   */

public class BinarySearchTree extends BinaryTreeBasis implements SearchTreeInterface
{
    /**  Size variable holds total number of nodes in BST */
   private int size;

   /** BST Constructor that calls parent constructor BinaryTreeBasis */
   public BinarySearchTree()
   {
      super();
   }
   
   /** The method retrieve takes in a Object of Comparable. 
      * Its reteives the item from the getRootNode() methods using the searchKey 
      * which was passed in.*/

   public KeyedItem retrieve(Comparable searchKey)
   {
      assert validateBSTProperty() : "Invalid BST during retrieval: " + searchKey;
      assert validateSize() : "Incorrect BST size during retrieval: " + searchKey;
      return retrieveItem(getRootNode(), searchKey);
   }

   /** The method takes a KeyedItem object and throows TreeException
      *Preconditions: But have a KeyedItem object
      *Postconditions: Possible invalids insertions */
   public void insert(KeyedItem item) throws TreeException
   {
      setRootNode(insertItem(getRootNode(), item));
      size++;
      assert validateBSTProperty() : "Invalid BST after insertion: " + item.getKey();
      assert validateSize() : "Incorrect BST size after insertion: " + item.getKey();
   }

   /** This method deletes a node
      Precondition: searchKey to find the node 
      Postcondition: Possible invalid deletion*/
   public void delete(Comparable searchKey) throws TreeException
   {
      setRootNode(deleteItem(getRootNode(), searchKey));
      size--;
      assert validateBSTProperty() : "Invalid BST after deletion: " + searchKey;
      assert validateSize() : "Incorrect BST size after deletion: " + searchKey;
   }

   /** Called by retrieve() to navigate BST.
      * Preconditions: TreeNode and Comparable key to navigate the BST
      * Postconditions: KeyedItem returned that matches the search key.*/
   protected KeyedItem retrieveItem(TreeNode tNode, Comparable searchKey)
   {
      //disallow duplicates so that you always know which object to retrieve (or delete)
      //you could return a list with all duplicate search keys (but delete is still a problem)
      KeyedItem treeItem;

      if (tNode == null)
      {
         treeItem = null;
      }
      else
      {
         KeyedItem nodeItem = (KeyedItem) tNode.getItem();
         int comparison = searchKey.compareTo(nodeItem.getKey());

         if (comparison == 0)
         {
            // item is in the root of some subtree
            //treeItem = nodeItem;
            treeItem = retrieveNode(tNode, searchKey);
         }
         else if (comparison < 0)
         {
            // search the left subtree
            //treeItem = retrieveItem(tNode.getLeft(), searchKey);
            treeItem = retrieveLeft(tNode, searchKey);
         }
         else
         {
            // search the right subtree
            //treeItem = retrieveItem(tNode.getRight(), searchKey);
            treeItem = retrieveRight(tNode, searchKey);
         }
      }
      return treeItem;
   }
   /** Retrieves the node
      Postconditions: Successful Retrieved
      Preconditions: TreeNode object and a searchKey */
   protected KeyedItem retrieveNode(TreeNode tNode, Comparable searchKey)
   {
      return (KeyedItem) tNode.getItem();
   }
   
   /** Retrieves a node in the left
      Postconditions: TreeNode Retrieved
      Preconditions: TreeNode object and a searchKey
      */
   protected KeyedItem retrieveLeft(TreeNode tNode, Comparable searchKey)
   {
      return retrieveItem(tNode.getLeft(), searchKey);
   }
   
   /** Retriebes a node in the right 
      *Preconditions: TreeNode Object and a searchKey.
      *Postconditions: Treenode Retrieved */
   protected KeyedItem retrieveRight(TreeNode tNode, Comparable searchKey)
   {
      return retrieveItem(tNode.getRight(), searchKey);
   }

   /** Called by insert() to place KeyedItem into BST.
      *Preconditions: TreeNode and KeyedItem to be placed into BST
      *Postconditions: TreeNode Inserted into BST*/
   protected TreeNode insertItem(TreeNode tNode, KeyedItem item) throws TreeException
   {

      if (tNode == null)
      {
         // position of insertion found; insert after leaf
         // create a new node
         tNode = new TreeNode(item);
         return tNode;
      }

      TreeNode subtree;
      KeyedItem nodeItem = (KeyedItem)tNode.getItem();
      int comparison = item.getKey().compareTo(nodeItem.getKey());

      // search for the insertion position
      if (comparison == 0)
      {
         tNode = insertDuplicate(tNode, item);
      }
      else if (comparison < 0)
      {
         // search the left subtree
         tNode = insertLeft(tNode, item);
      }
      else
      {
         // search the right subtree
         tNode = insertRight(tNode, item);
      }

      return tNode;
   }
   /** Called by insertTime(); methods decomp.
      * Preconditions: Duplicate item found.
        Postconditions: Throw TreeException*/

   protected TreeNode insertDuplicate(TreeNode tNode, KeyedItem item) throws TreeException
   {
       throw new TreeException ("Cannot add duplicate.");
   }

   /** Called by insertItem(); methods decomp.
      * Precondition: Takes a TreeNode and KeyedItem to be inserted on the left size of a node.
      * Postconditions: Inserted node. */
   protected TreeNode insertLeft(TreeNode tNode, KeyedItem item)
   {
       TreeNode subTree = insertItem(tNode.getLeft(), item);
       tNode.setLeft(subTree);
       return tNode;
   }
   
   /** Called by insertItem(); method deomp.
      *Preconditions: Takes a TreeNode and KeyedItem to be inserted on the right side of  node.
      *Postconditionds: Inserted node. */
   protected TreeNode insertRight(TreeNode tNode, KeyedItem item)
   {
       TreeNode subTree = insertItem(tNode.getRight(), item);
       tNode.setRight(subTree);
       return tNode;
   }

   /** Called by delete().
    * Predoncitions: Takes aa TreeNOde and KeyedItem to be deleted.
    * Postconditions: Deleted node.
    */
   protected TreeNode deleteItem(TreeNode tNode, Comparable searchKey) throws TreeException
   {

      if (tNode == null)
      {
         throw new TreeException("Item not found");
      }

      TreeNode subtree;
      KeyedItem nodeItem = (KeyedItem)tNode.getItem();
      int comparison = searchKey.compareTo(nodeItem.getKey());

      if (comparison == 0)
      {
         // item is in the root of some subtree
         tNode = deleteNode(tNode);  // delete the item
      }
      // else search for the item
      else if (comparison < 0)
      {
         // search the left subtree
         tNode = deleteLeft(tNode, searchKey);
      }
      else
      {
         // search the right subtree
         tNode = deleteRight(tNode, searchKey);
      }

      return tNode;
   }

   /** Called by deleteItem(); method decomp.
      *Preconditions: Takes a TreeNode and KeyedItem to be deleted.
      *Postconditions: Deleted node.
       */
      
   
   protected TreeNode deleteNode(TreeNode tNode)
   {
      // Algorithm note: There are four cases to consider:
      //   1. The tNode is a leaf.
      //   2. The tNode has no left child.
      //   3. The tNode has no right child.
      //   4. The tNode has two children.
      // Calls: findLeftmost and deleteLeftmost

      // test for a leaf --  this test is taken care of by the next two
      if ((tNode.getLeft() == null) && (tNode.getRight() == null))
      {
         return null;
      }

      // test for no left child
      else if (tNode.getLeft() == null)
      {
         return tNode.getRight();
      }

      // test for no right child
      else if (tNode.getRight() == null)
      {
         return tNode.getLeft();
      }

      // there are two children:
      // retrieve and delete the inorder successor
      else
      {
         KeyedItem replacementItem = findLeftmost(tNode.getRight());
         tNode.setItem(replacementItem);
         TreeNode subtree = deleteLeftmost(tNode.getRight());
         tNode.setRight(subtree);
         return tNode;
      }
   }
   /** Find the left most side of the BST*/
   protected KeyedItem findLeftmost(TreeNode tNode)
   {
      if (tNode.getLeft() == null)
      {
         return (KeyedItem)tNode.getItem();
      }
      else
      {
         return findLeftmost(tNode.getLeft());
      }
   }

   /** Deletes the left most side of the BST */
   protected TreeNode deleteLeftmost(TreeNode tNode)
   {
      if (tNode.getLeft() == null)
      {
         return tNode.getRight();
      }
      else
      {
         TreeNode subtree = deleteLeftmost(tNode.getLeft());
         tNode.setLeft(subtree);
         return tNode;
      }
   }

   /** Deletes the an item im the let side of the TreeNode*/
   protected TreeNode deleteLeft(TreeNode tNode, Comparable searchKey)
   {
       TreeNode subTree = deleteItem(tNode.getLeft(), searchKey);
       tNode.setLeft(subTree);
       return tNode;
   }

   /** Deletes an item in the right side of the TreeNode
      *called by deleteItem();
      *Preconditions: Takes a TreeNode and KeyedItem to be deleted.
      *Postconditions: Deleted node. */
   protected TreeNode deleteRight(TreeNode tNode, Comparable searchKey)
   {
       TreeNode subTree = deleteItem(tNode.getRight(), searchKey);
       tNode.setRight(subTree);
       return tNode;
   }

   /**  Rotates the BST to the left 
      *Preconditions: TreeNode
      *Postconditions: New BST off of rotation properties. */
   protected TreeNode rotateLeft(TreeNode tNode)
   {
      TreeNode right = tNode.getRight();
      TreeNode rightleft = right.getLeft();

      tNode.setRight(rightleft);
      right.setLeft(tNode);

      return right;
   }

   /** Rotates the BST to the right.
      *Preconditions: TreeNode
      *Postconditions: New BST based off of rotation properties. */
   protected TreeNode rotateRight(TreeNode tNode)
   {
      TreeNode left = tNode.getLeft();
      TreeNode leftright = left.getRight();

      tNode.setLeft(leftright);
      left.setRight(tNode);

      return left;
   }

   /** Determines if the BST is balanced according to BST property.
      *Preconditions: none
      *Postconditions: boolean of condition */
   public boolean isBalanced() {
      //return isBalanced(getRootNode());
      return height() <= 1;
   }

   /**  Helper method to determine if the BST is balanced according to BST property.
      *Preconditions: TreeNode position.
      *Postconditions: Boolean of condition. */
   protected boolean isBalanced(TreeNode tNode)
   {
      if (tNode == null)
      {
          return true;
      }

      boolean balanced = isBalanced(tNode.getLeft());

      if (!balanced)
      {
          return balanced;
      }

      balanced = isBalanced(tNode.getRight());

      if (!balanced)
      {
          return balanced;
      }

      int leftHeight = getHeight(tNode.getLeft());
      int rightHeight = getHeight(tNode.getRight());

      if (leftHeight > rightHeight)
      {
          return leftHeight - rightHeight > 1;
      }
      else if (rightHeight > leftHeight)
      {
          return rightHeight - leftHeight > 1;
      }

      return balanced;
   }

   /** Returns the height of the BST.
      *Preconditions: TreeNode to keep position.
      *Postconditions: integer of BST height.*/
   public int height()
   {
      return getHeight(getRootNode());
   }

   /** Helper method to return height of BST
      *Preconditions: TreeNOde to keep position
      *Postconditions: Integer of BST height*/
   protected int getHeight(TreeNode tNode)
   {
      if (tNode == null)
      {
          return 0;
      }

      int height = 0;
      int leftHeight = getHeight(tNode.getLeft());
      int rightHeight = getHeight(tNode.getRight());

      if (leftHeight >= rightHeight)
      {
          height = leftHeight + 1;
      }
      else
      {
          height = rightHeight + 1;
      }

      return height;
   }

   /** Determines if BST is valid according to properties.
    * Preconditions: none
    * Postconditions: Boolean return of valid BST property.
    */
   protected boolean validateBSTProperty() {
      boolean isValid = true;
      TreeIterator tIter = iterator();
      tIter.setInorder();

      if (!tIter.hasNext())
      {
          return true;
      }

      Comparable key1 = ((KeyedItem) tIter.next()).getKey();

      while (tIter.hasNext())
      {
          Comparable key2 = ((KeyedItem) tIter.next()).getKey();
          if (key1.compareTo(key2) > 0)
          {
             isValid = false;
             break;
          }

          key1 = key2;
      }

      return isValid;
   }

   /** Determines if the instance variable matches the actual size of the BST
      Precondition: none
      Postconditions: boolean of the tested condition*/
   protected boolean validateSize() {
      return size() == getSize();
   }

   /** Returns the variables size */
   public int size()
   {
       return size;
   }

   public int getSize()
   {
       int count = 0;
       TreeIterator tIter = iterator();
       tIter.setInorder();

       while (tIter.hasNext())
       {
           tIter.next();
           count++;
       }

       return count;
   }
}
