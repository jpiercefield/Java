import java.util.ArrayList;
import java.util.Iterator;

public class BSTDriver
{
   public static void main(String[] args)
   {
      BinarySearchTree bst = new BinarySearchTree();
      CD[] cds_array = readMusic("cds.txt");

      printBST(bst, "BST properties with an empty tree:");

      // Test insertion of all elements
      for (int i = 0; i < cds_array.length; i++)
      {
          bst.insert(cds_array[i]);
      }

      printBST(bst, "BST properties after adding CDs from cds.txt:");

      // Test deletion of all elements
      TreeIterator tIter = bst.iterator();
      tIter.setInorder();

      while (tIter.hasNext())
      {
          KeyedItem item = (KeyedItem) tIter.next();
          bst.delete(item.getKey());
      }

      printBST(bst, "BST properties after deleting CDs:");

      // Add all of the CDs back again
      for (int i = 0; i < cds_array.length; i++)
      {
          bst.insert(cds_array[i]);
      }

      printBST(bst, "BST properties after CDs are added again:");

      // Force the tree to be empty
      // Throws TreeException for incorrect size on next insertion
      //bst.makeEmpty();
      //printBST(bst, "BST properties after calling makeEmpty():");

      // Retrieve the root of the tree
      TreeNode rootNode = bst.getRootNode();
      KeyedItem item = (KeyedItem) rootNode.getItem();
      Comparable searchKey = item.getKey();
      KeyedItem result = bst.retrieve(searchKey);
      printBST(bst, "Searching for root item: " + searchKey);
      System.out.println("The root item is: " + item);

      // Retrieve an existing element other than the root of the tree
      result = bst.retrieve("The Thin Line Between");
      printBST(bst, "Searching for existing item: " + result.getKey());
      System.out.println("The item is: " + result );

      // Retrieve an element which does not exist in the tree
      result = bst.retrieve("");
      printBST(bst, "Searching for non-existing item...");
      System.out.println("The item is: " + result );

      // Retrieve the element which is the left-most leaf of the tree
      item = bst.findLeftmost(rootNode);
      result = bst.retrieve(item.getKey());
      printBST(bst, "Searching for left-most leaf: " + result.getKey());
      System.out.println("The item is: " + result );

      // Delete the root of the tree
      item = (KeyedItem) bst.getRootItem();
      bst.delete(item.getKey());
      printBST(bst, "Deleting the root node: " + item.getKey());
      System.out.println("The root node is now: " + bst.getRootItem());

      // Deleting the root node again
      item = (KeyedItem) bst.getRootItem();
      bst.delete(item.getKey());
      printBST(bst, "Deleting the root node again: " + item.getKey());
      System.out.println("The root node is now: " + bst.getRootItem());

      // Deleting an existing elmeent other than the root of the tree
      result = bst.retrieve("Against The Elements");
      bst.delete(result.getKey());
      printBST(bst, "Deleting an existing item: " + result.getKey());

      // Deleting an element which does not exist in the tree
      // Throws TreeException for Item not found
      //bst.delete("This doesn't exist!");
      //printBST(bst, "Deleting a non-existing item...");
   }

   private static void printBST(BinarySearchTree bst, String msg)
   {

      System.out.println("\n-------------------------------------------------");
      System.out.println(msg);
      System.out.println("Height: " + bst.height());
      System.out.println("Size: " + bst.size());
      System.out.println("Balance: " + bst.isBalanced());
      System.out.println("Is empty: " + bst.isEmpty());
      System.out.println("Valid: " + bst.validateBSTProperty());
   }

   private static CD[] readMusic(String fileName)
   {
      FileIO file = new FileIO(fileName, FileIO.FOR_READING);
      String str = file.readLine();
      ArrayList<CD> cds = new ArrayList<CD>();
      while (!file.EOF())
      {
         String title = file.readLine();
         int year = Integer.parseInt(file.readLine());
         int rating = Integer.parseInt(file.readLine());
         int numTracks = Integer.parseInt(file.readLine());
         CD cd = new CD(title, str, year, rating, numTracks);

         cds.add(cd);
         int tracks = 1;

         while (tracks <= numTracks)
         {
            String temp = file.readLine();
            String[] line = temp.split(",");
            String len = line[0];
            String songTitle = line[1];
            cd.addSong(songTitle, len);
            tracks++;
         }

         str = file.readLine();
      }

      CD[] cds_array = new CD[cds.size()];
      int i = 0;
      for(CD cd : cds)
      {
         cds_array[i] = cds.get(i);
         i++;
      }
      return cds_array;
   }
}
