public interface Command 
{
   public void execute(Object item);
}