import java.util.ArrayList;

public class WorstCDs implements Command
{
   private ArrayList<CD> cds = new ArrayList<CD>();
   private int worst = 11;
   
   public void execute(Object item) {
      CD cd = (CD)item;
      int rating = cd.getRating();
      if (rating == worst) {
         cds.add(cd);
      } else if (rating < worst) {
         cds = new ArrayList<CD>();
         worst = rating;
         cds.add(cd);
      }
   }
   
   public ArrayList<CD> getWorstCDs() {
      return cds;
   }
   
}