public class LongestSong implements Command
{
   
   private Song longest;
   private int length = 0;
   
   public void execute(Object item) {
      CD cd = (CD) item;
      int numTracks = cd.getNumberOfTracks();
      for (int i = 0; i < numTracks; i++) {
         Song song = cd.getSong(i);
         if (song.getLength() >= length) {
            longest = song;
            length = song.getLength();
         }
      }
   }
   
   public Song getLongestSong() {
      return longest;
   }
   
}