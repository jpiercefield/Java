import java.util.Iterator;

public interface TreeIterator extends Iterator
{
   public void setInorder();
   public void setPreorder();
   public void setPostorder();
}