public interface Execute 
{
   public void execute(Command command);
}