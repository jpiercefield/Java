public final class AVLTree extends BinarySearchTree implements Execute
{
   private boolean avlFlag;

   public AVLTree()  
   {
      super();
   } 
   
   public void execute(Command command) 
   {
      for (Object o : this) 
      {
         command.execute(o);
      }
   }

   public void insert(KeyedItem item) throws TreeException
   {
      super.insert(item);
      avlFlag = false;
      assert isBalanced() : "Tree is not balanced after insertion.";
   } 

   public void delete(Comparable sk) throws TreeException
   {
      super.delete(sk);
      avlFlag = false;
      assert isBalanced() : "Tree is not balanced after deletion.";
   }
   
   protected TreeNode createNode(KeyedItem item)
   {
      avlFlag = true;
      return new AVLTreeNode(item);
   }

   protected TreeNode insertLeft(TreeNode tNode, KeyedItem item)
   {
      TreeNode subtree = insertItem(tNode.getLeft(), item);
      tNode.setLeft(subtree);

      //check balance factor and rotate if necessary
      if (avlFlag)  //still need to check
      {
         tNode = avlFixAddLeft((AVLTreeNode)tNode);
      }
      return tNode;
   }
   
   protected TreeNode insertRight(TreeNode tNode, KeyedItem item)
   {
      TreeNode subtree = insertItem(tNode.getRight(), item);
      tNode.setRight(subtree);

      //check balance factor and rotate if necessary
      if (avlFlag)
      {
         tNode = avlFixAddRight((AVLTreeNode)tNode);
      }
      return tNode;
   }
   
   protected TreeNode deleteItem(TreeNode tNode, Comparable searchKey) 
   {
      TreeNode subtree;
      if (tNode == null) 
      {
         throw new TreeException("Item not found");
      }

      KeyedItem nodeItem = (KeyedItem) tNode.getItem();
      int comparison = searchKey.compareTo(nodeItem.getKey());

      if (comparison == 0) 
      {
         // item is in the root of some subtree
         //found something to delete so set avlFlag to true
         avlFlag = true;  //will delete a node from the tree, need to check balancing
         tNode = deleteNode(tNode);  // delete the item
      }
      // else search for the item
      else if (comparison < 0) 
      {
         // search the left subtree
         subtree = deleteItem(tNode.getLeft(), searchKey);
         tNode.setLeft(subtree);

         //check balance factors and rotate if necessary
         if (avlFlag)
         {
            tNode = avlFixDeleteLeft((AVLTreeNode)tNode);  //came from left
         }
      }
      else 
      { 
         // search the right subtree
         subtree = deleteItem(tNode.getRight(), searchKey);
         tNode.setRight(subtree);

         //check balance factors and rotate if necessary
         if (avlFlag)
         {
            tNode = avlFixDeleteRight((AVLTreeNode)tNode);  //came from right
         }
      }  

      return tNode;
   } 
   
   @Override
   protected TreeNode deleteInorderSuccessor(TreeNode tNode)
   {
      KeyedItem replacementItem = findLeftmost(tNode.getRight());
      tNode.setItem(replacementItem);
      tNode.setRight(deleteLeftmost(tNode.getRight()));
      if (avlFlag)
      {
         //inorder successor: take a right, then keep going left
         tNode = avlFixDeleteRight((AVLTreeNode)tNode);  //came from right
      }
      return tNode;
   }

   //find the inorder successor
   //this method is overridden to allow checking for balancing
   @Override
   protected TreeNode deleteLeftmost(TreeNode tNode) 
   {
      if (tNode.getLeft() == null) 
      {
         avlFlag = true;
         return tNode.getRight();
      }
      else 
      {
         tNode.setLeft(deleteLeftmost(tNode.getLeft()));
         if (avlFlag)
         {
            tNode = avlFixDeleteLeft((AVLTreeNode)tNode);  //keep going left
         }
         return tNode;
      }  
   }   
   
   protected AVLTreeNode avlFixAddLeft(AVLTreeNode tNode) {
      AVL factor;
      AVLTreeNode temp = null;
      
      tNode.insertLeft();
      factor = tNode.getBalanceFactor();
      
      if (factor == AVL.BALANCED)  //change to balanced, stop
      {
         avlFlag = false; //no more to do this time around
         return tNode;
      }
      
      if (factor == AVL.LEFT || factor == AVL.RIGHT)
      {
         return tNode;  
      }
      else {
         AVLTreeNode left = tNode.getLeft();
         
         if (factor == AVL.LEFT_HEAVY && tNode.getLeft().getBalanceFactor() == AVL.RIGHT)
         {
            AVLTreeNode leftRight = left.getRight();
            AVL bF = leftRight.getBalanceFactor();

            if (bF == AVL.BALANCED)  //can happen
            {
               tNode.setBalanceFactor(AVL.BALANCED);
               left.setBalanceFactor(AVL.BALANCED);
            }
            else if (bF == AVL.RIGHT)
            {
               tNode.setBalanceFactor(AVL.BALANCED);
               left.setBalanceFactor(AVL.LEFT);
            }
            else
            {
               tNode.setBalanceFactor(AVL.RIGHT);  
               left.setBalanceFactor(AVL.BALANCED);  
            }

            leftRight.setBalanceFactor(AVL.BALANCED);

            temp = (AVLTreeNode) rotateLeft(left);
            tNode.setLeft(temp);
            temp = (AVLTreeNode) rotateRight(tNode);  //don't want to set parent links just yet (done in insert method)
            System.out.println("DLR");
         }
         else if (factor == AVL.LEFT_HEAVY && left.getBalanceFactor() == AVL.LEFT)
         {
            tNode.setBalanceFactor(AVL.BALANCED);
            left.setBalanceFactor(AVL.BALANCED);
            temp = (AVLTreeNode) rotateRight(tNode);
            System.out.println("SR");
         }
      }
      
      avlFlag = false; //basically, stop checking 
      return temp;  //return the replacement node for this position, linked in recursively
   }
   
   protected AVLTreeNode avlFixAddRight(AVLTreeNode tNode) {
      AVL factor;
      AVLTreeNode temp;
      
      tNode.insertRight();
      factor = tNode.getBalanceFactor();
      if (factor == AVL.BALANCED)  //change to balanced, stop
      {
         avlFlag = false; 
         return tNode;
      }
      
      if (factor == AVL.LEFT || factor == AVL.RIGHT)
      {
         return tNode;  
      } else {
         AVLTreeNode right = tNode.getRight();
         
         //double rotate right then left
         if (factor == AVL.RIGHT_HEAVY && right.getBalanceFactor() == AVL.LEFT)
         {
            AVLTreeNode rightLeft = right.getLeft();
            AVL bF = rightLeft.getBalanceFactor();

            if (bF == AVL.BALANCED)  //can happen
            {
               tNode.setBalanceFactor(AVL.BALANCED);
               right.setBalanceFactor(AVL.BALANCED);
            }
            else if (bF == AVL.RIGHT)
            {
               tNode.setBalanceFactor(AVL.LEFT);
               right.setBalanceFactor(AVL.BALANCED);
            }
            else
            {
               tNode.setBalanceFactor(AVL.BALANCED);
               right.setBalanceFactor(AVL.RIGHT);
            }

            rightLeft.setBalanceFactor(AVL.BALANCED);

            temp = (AVLTreeNode) rotateRight(right);
            tNode.setRight(temp);
            temp = (AVLTreeNode) rotateLeft(tNode);
            System.out.println("DRL");
         }
         else
         {
            tNode.setBalanceFactor(AVL.BALANCED);
            right.setBalanceFactor(AVL.BALANCED);
            temp = (AVLTreeNode) rotateLeft(tNode);
            System.out.println("SL");
         }
      }
      
      avlFlag = false; //basically, stop checking 
      return temp;  //return the replacement node for this position, linked in recursively
   }

   protected AVLTreeNode avlFixDeleteLeft(AVLTreeNode tNode) {
      AVL factor;
      AVLTreeNode temp = null;
      
      factor = tNode.getBalanceFactor();
      tNode.deleteLeft();
      if (factor == AVL.BALANCED)  //change from zero--  STOP
      {
         avlFlag = false; //no more to do this time around
         return tNode;
      }
      factor = tNode.getBalanceFactor();
      
      if (factor == AVL.LEFT || factor == AVL.RIGHT || factor == AVL.BALANCED)
      {
         return tNode;  //need to keep checking, but no rotations necessary as yet
      }
      else {
         AVLTreeNode right = tNode.getRight();
         
         if (factor == AVL.RIGHT_HEAVY && right.getBalanceFactor() == AVL.BALANCED)
         {
            tNode.setBalanceFactor(AVL.RIGHT);
            right.setBalanceFactor(AVL.LEFT);
            temp = (AVLTreeNode) rotateLeft(tNode);
            avlFlag = false;  //STOP
            System.out.println("SL0");
         }
         
         else if (factor == AVL.RIGHT_HEAVY && right.getBalanceFactor() == AVL.RIGHT)
         {
            tNode.setBalanceFactor(AVL.BALANCED);
            right.setBalanceFactor(AVL.BALANCED);
            temp = (AVLTreeNode) rotateLeft(tNode);
            System.out.println("SL");
         }
         
         else
         {
            AVLTreeNode rightLeft = right.getLeft();
            AVL bF = rightLeft.getBalanceFactor();

            if (bF == AVL.BALANCED)  
            {
               tNode.setBalanceFactor(AVL.BALANCED);
               right.setBalanceFactor(AVL.BALANCED);
            }
            else if (bF == AVL.RIGHT)
            {
               tNode.setBalanceFactor(AVL.LEFT);
               right.setBalanceFactor(AVL.BALANCED);
            }
            else
            {
               tNode.setBalanceFactor(AVL.BALANCED);
               right.setBalanceFactor(AVL.RIGHT);
            }
            rightLeft.setBalanceFactor(AVL.BALANCED);

            temp = (AVLTreeNode) rotateRight(right);
            tNode.setRight(temp);
            temp = (AVLTreeNode) rotateLeft(tNode);
            System.out.println("DRL");
         }
         
         return temp;
      }
   }
   
   protected AVLTreeNode avlFixDeleteRight(AVLTreeNode tNode) {
      AVL factor;
      AVLTreeNode temp = null;
      
      factor = tNode.getBalanceFactor();
      tNode.deleteRight();
      if (factor == AVL.BALANCED) //change from zero--  STOP
      {
         avlFlag = false; //no more to do this time around
         return tNode;
      }
      factor = tNode.getBalanceFactor();
      
      if (factor == AVL.LEFT || factor == AVL.RIGHT || factor == AVL.BALANCED)
      {
         return tNode;  //need to keep checking, but no rotations necessary as yet
      }
      else
      {
         AVLTreeNode left = tNode.getLeft();
         
         if (factor == AVL.LEFT_HEAVY && left.getBalanceFactor() == AVL.BALANCED)
         {
            tNode.setBalanceFactor(AVL.LEFT);
            left.setBalanceFactor(AVL.RIGHT);
            temp = (AVLTreeNode) rotateRight(tNode);
            avlFlag = false;  //STOP
            System.out.println("SR0");
         }
         
         else if (factor == AVL.LEFT_HEAVY && left.getBalanceFactor() == AVL.LEFT)
         {
            tNode.setBalanceFactor(AVL.BALANCED);
            left.setBalanceFactor(AVL.BALANCED);
            temp = (AVLTreeNode) rotateRight(tNode);
            System.out.println("SR");
         }
         
         else if (factor == AVL.LEFT_HEAVY && left.getBalanceFactor() == AVL.RIGHT)
         {
            AVLTreeNode leftRight = left.getRight();
            AVL bF = leftRight.getBalanceFactor();
        
            if (bF == AVL.BALANCED) 
            {
               tNode.setBalanceFactor(AVL.BALANCED);
               left.setBalanceFactor(AVL.BALANCED);
            }
            else if (bF == AVL.RIGHT)
            {
               tNode.setBalanceFactor(AVL.BALANCED);
               left.setBalanceFactor(AVL.LEFT);
            }
            else
            {
               tNode.setBalanceFactor(AVL.RIGHT);  
               left.setBalanceFactor(AVL.BALANCED);  
            }

            leftRight.setBalanceFactor(AVL.BALANCED);

            temp = (AVLTreeNode) rotateLeft(left);
            tNode.setLeft(temp);
            temp = (AVLTreeNode) rotateRight(tNode);
            System.out.println("DLR");
         }
         
         return temp;
      }
   }
   
} 