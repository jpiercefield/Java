import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class AVLDriver
{
   public static void main(String[] args)
   {
      //call the height and isBalanced methods and display the results with all items inserted
      CD[] cds = readMusic("cds.txt");
      AVLTree tree = new AVLTree();
      for (int i = 0; i < cds.length; i++) {
         tree.insert(cds[i]);
      }
      printInfo(tree, "All CDs should be added.");
      
      WorstCDs worstCDs = new WorstCDs();
      LongestSong longestSong = new LongestSong();
      
      tree.execute(worstCDs);
      tree.execute(longestSong);
      
      ArrayList<CD> theWorst = worstCDs.getWorstCDs();
      Song longSong = longestSong.getLongestSong();
      
      System.out.println("The worst CDs:");
      Iterator<CD> iter = theWorst.iterator();
      while (iter.hasNext()) {
         System.out.println(iter.next().toString());
      }
      
      System.out.println("Longest song: " + longSong.getTitle());
      
   }
   
   private static void printInfo(BinarySearchTree tree, String message) {
      System.out.println();
      System.out.println("================================================");
      System.out.println();
      displayTree(tree);
      System.out.println();
      System.out.println("Size: " + tree.size());
      System.out.println("Height: " + tree.height());
      System.out.println("Balanced: " + (tree.isBalanced() ? "true" : "false"));
      System.out.println();
      System.out.println(message);
      System.out.println();
      pauseOutput();
      System.out.println("================================================");
      System.out.println();
   }
   
   private static void pauseOutput() {
      Scanner in = new Scanner(System.in);
      System.out.print("Press <Enter> to continue...");
      in.nextLine();
   }
   
   private static void displayTree(BinarySearchTree tree) {
      Iterator iter = tree.iterator();
      while (iter.hasNext()) {
         System.out.println(iter.next().toString());
      }
   }

   private static CD[] readMusic(String fileName)
   {
      FileIO file = new FileIO(fileName, FileIO.FOR_READING);
      String str = file.readLine();
      ArrayList<CD> cds = new ArrayList<CD>();
      while (!file.EOF())
      {
         String title = file.readLine();
         int year = Integer.parseInt(file.readLine());
         int rating = Integer.parseInt(file.readLine());
         int numTracks = Integer.parseInt(file.readLine());
         CD cd = new CD(title, str, year, rating, numTracks);

         cds.add(cd);
         int tracks = 1;

         while (tracks <= numTracks)
         {
            String temp = file.readLine();
            String[] line = temp.split(",");
            String len = line[0];
            String songTitle = line[1];
            cd.addSong(songTitle, len);
            tracks++;
         }

         str = file.readLine();
      }

      CD[] cds_array = new CD[cds.size()];
      int i = 0;
      for(CD cd : cds)
      {
         cds_array[i] = cds.get(i);
         i++;
      }
      return cds_array;
   }
}