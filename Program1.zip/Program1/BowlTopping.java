public abstract class BowlTopping extends BowlItem{

    public boolean equals(BowlTopping bt)
    {
        //check all toppings.. need more if statements
        if(bt instanceof Tomato && this instanceof Tomato){
            return true;
        }
        else if(bt instanceof Avocado && this instanceof Avocado){
            return true;
        }
        else if(bt instanceof Peppers && this instanceof Peppers){
            return true;
        }
        else if(bt instanceof Edamame && this instanceof Edamame){
            return true;
        }else{
            return false;
        }
        
    }
    
    public BowlTopping(BowlProtein next){
        super(next);
    }
    
    public BowlTopping(BowlTopping next){
        super(next);
    }
    
    public double cost(){
        return .44;
    }
    
    public String toString(){
        return "Topping: ";
    }
    
    public boolean isDuplicate()
    {
        return super.isDuplicate(this);
    }
}