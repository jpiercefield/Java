public abstract class BowlBase extends BowlItem{
    
    public BowlBase(){
        super(null);
    }
    
    public abstract double cost();
    
    public String toString()
    {
        return "Base: ";
    }
}