public class BowlBuilder{

    //constructor
    private BowlItem bowlItem;
    private boolean baseTrue = false;
    private boolean proteinTrue = false;

    private boolean hasBase()
    {
        return baseTrue;
    }

    private boolean hasProtein()
    {
        return proteinTrue;
    }

    //creates the BowlBase if the input is okay, else does nothing and returns false
    public boolean buildBase(char baseChar){
        baseChar = Character.toUpperCase(baseChar);
        switch(baseChar){
            case 'Q':
            bowlItem = new Quinoa();
            break;
            case 'G':
            bowlItem = new MixedGreen();
            break;
            case 'P':
            bowlItem = new BakedPotato();
            break;
            default:
            return false;

        }
        baseTrue = true;
        return true;
    }

    //creates a BowlProtein and adds it to the order if the input is okay
    public boolean buildProtein(char proteinChar){
        if(baseTrue){
            proteinChar = Character.toUpperCase(proteinChar);
            if(bowlItem instanceof BowlBase){
                switch(proteinChar){
                    case 'G':
                    bowlItem = new GrilledChicken(((BowlBase)bowlItem));
                    break;
                    case 'S':
                    bowlItem = new Steak(((BowlBase)bowlItem));
                    break;
                    case 'B':
                    bowlItem = new BlackBeans(((BowlBase)bowlItem));
                    break;
                    case 'D':
                    if(proteinTrue)
                    {
                        return true;
                    }else{
                        return false;
                    }    
                    default:
                    return false;
                }
            }else if(bowlItem instanceof BowlProtein){
                switch(proteinChar){
                    case 'G':
                    bowlItem = new GrilledChicken(((BowlProtein)bowlItem));
                    break;
                    case 'S':
                    bowlItem = new Steak(((BowlProtein)bowlItem));
                    break;
                    case 'B':
                    bowlItem = new BlackBeans(((BowlProtein)bowlItem));
                    break;
                    case 'D':
                    break;
                    default:
                    return false;
                }
            }
            proteinTrue = true;
            return true;
        }else{
            System.err.println("NEED TO ADD A BASE FIRST");
            return false;
        }
    }

    //creates a BowlTopping and adds it to the order if the input is okay
    public boolean buildTopping(char topChar){
		if(proteinTrue){
			BowlItem tempItem = bowlItem;
			BowlItem oldBowlItem = bowlItem;
			topChar = Character.toUpperCase(topChar);
			if(bowlItem instanceof BowlTopping){
				switch(topChar){
				case 'T':
					tempItem = new Tomato(((BowlTopping)bowlItem));
					break;
				case 'A':
					tempItem = new Avocado(((BowlTopping)bowlItem));
					break;
				case 'P':
					tempItem = new Peppers(((BowlTopping)bowlItem));
					break;
				case 'E':
					tempItem = new Edamame(((BowlTopping)bowlItem));
					break;
				case 'D':
					return true;
				default:
					return false;
				}
			}else if(bowlItem instanceof BowlProtein){
				switch(topChar){
				case 'T':
					tempItem = new Tomato(((BowlProtein)bowlItem));
					break;
				case 'A':
					tempItem = new Avocado(((BowlProtein)bowlItem));
					break;
				case 'P':
					tempItem = new Peppers(((BowlProtein)bowlItem));
					break;
				case 'E':
					tempItem = new Edamame(((BowlProtein)bowlItem));
					break;
				case 'D':
					return true;
				default:
					return false;
				}
			}
			
			if(((BowlTopping)tempItem).isDuplicate()){
				bowlItem = oldBowlItem;
			}else{
				bowlItem = tempItem;
			}
			return false;
		}else{
			System.err.println("NO PROTEIN ADDED");
			return false;
		}
	}
    
    

        //returns the finished bowl or null if the order is incomplete
    public BowlItem orderBowl(){
            if(proteinTrue)
            {
                return bowlItem;
            }else{
                return null;
            }
    }

}