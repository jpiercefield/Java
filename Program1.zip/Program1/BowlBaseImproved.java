public class BowlBaseImproved extends BowlItem{






    //added to the BowlTopping class, called by builder, calls the below method
    public boolean isDuplicate(){


    }

    //added to BowlItem and calls the below method as necessary, uses instanceof
    //(do not use an explicit loop in this method)
    public boolean isDuplicate(BowlTopping check){


    }

    //added to each specific BowlTopping subclass to see if bt and this are the same
    //type of condiment (uses instanceof)
    public boolean equals(BowlTopping bt){


    }
    
    //one more detail must be included to get this to work involving the complexity
    //of calling methods with overridden and overloaded methods

}