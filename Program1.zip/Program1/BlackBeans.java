public class BlackBeans extends BowlProtein{
    
    public BlackBeans(BowlBase next){
        super(next);
    }
    
    public BlackBeans(BowlProtein next){
        super(next);
    }
    
    public String toString(){
        
        return super.toString()+"Black Beans\r\n";
    }
    
}
