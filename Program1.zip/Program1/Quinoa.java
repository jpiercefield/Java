public class Quinoa extends BowlBase{

    public double cost(){
        
        return 2.79;
    }
    
    public String toString(){
        
        return super.toString()+"Quinoa\r\n";
    }
    
    
}
