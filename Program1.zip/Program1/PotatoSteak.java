public class PotatoSteak extends BowlBuilder
{
    // instance variables - replace the example below with your own
    public PotatoSteak()
    {
        buildBase('P');
        buildProtein('S');
        buildTopping('E');
        
    }
    
}
