public abstract class BowlItem{

    //constructor to set the next bowl item in the decorator design pattern
    private BowlItem nextBowlItem;
    private double cost;
    
    public BowlItem(BowlItem next)
    {
        if(next!=null)
        {
            System.out.println("Constructor Called: " +next.getClass());
        }
        if(next instanceof BowlTopping)
        {
            System.out.println(((BowlTopping)next).isDuplicate());
                if(!((BowlTopping)next).isDuplicate()){
                    nextBowlItem = next;
                }else{
                    
                }
            }else{
                nextBowlItem = next;
            }
        }
    
    //returns the cost of the next bowl item
    public double cost(){
        if(nextBowlItem!=null)
        {
            return nextBowlItem.cost();
        }
        return 0;

    }
    
    //returns the String description of the next bowl item
    public String toString(){
        if(nextBowlItem!=null)
        {
            return nextBowlItem.toString();
        }
        
        return "";
    }
    
    public boolean isDuplicate(BowlTopping topping){
        if(nextBowlItem!=null){
            if(topping.equals(nextBowlItem)){
                return true;
            }else{
                return nextBowlItem.isDuplicate(topping);
            }
        }else{
            return false;
        }
    }

}