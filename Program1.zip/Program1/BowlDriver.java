import java.io.File;
import java.util.Scanner;
import java.io.IOException;

public class BowlDriver{

    public static void main(String[] args)throws IOException{
        //static FileIO bla = new F
        boolean loop = true;
        while(loop)
        {
            String input = "";
            input = Keyboard.getKeyboard().readString("Would you like to order a bowl (y/n)? ");
            if(input.equals("y") || input.equals("Y"))
            {
                int newNum = 0;
                newNum = menu();
                BowlBuilder newBB = new BowlBuilder();
                BowlItem newBI = newBB.orderBowl();
                if(newNum == 1){
                    
                }else if(newNum == 2){
                    
                }else if(newNum == 3){
                    
                }
                
                
     
                
            
                
            }
            
        }

        


    //displays pre-built bowl options or "build your own", returns user menu selection (bowl is not built here)
    public static int menu(){
        System.out.println("\r\n1. Build Your Own");
        System.out.println("\r\n2. Mexican Salad");
        System.out.println("\r\n3. Quesadilla");
        int hello = 0;

        hello = Keyboard.getKeyboard().readInt("\r\nSelect from the above: ");
        return hello;

    }

    
    //calls the appropriate method on the builder until input is accepted by the builder
    private static void requestBase(BowlBuilder bb){

    }
    //adds proteins until user specifies done (at least one protein MUST be selected)
    private static void requestProteins(BowlBuilder bb){

        
    }

    //adds toppings until user specifies done (note how options disappear after selection)
    private static void requestToppings(BowlBuilder bb){

        
    }

    //displays the finished bowl order
    private static void showOrder(BowlItem bi){

    }
}