public class MexicanSalad extends BowlBuilder
{
    // instance variables - replace the example below with your own
    public MexicanSalad()
    {
        buildBase('G');
        buildTopping('P');
        buildTopping('T');
        buildTopping('A');
        buildProtein('B');
    }
    
    
}
