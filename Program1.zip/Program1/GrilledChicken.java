public class GrilledChicken extends BowlProtein{
    
    public GrilledChicken(BowlBase next){
        super(next);
    }
    
    public GrilledChicken(BowlProtein next){
        super(next);
    }
    
    public String toString(){
        return super.toString()+"Grilled Chicken:\r\n";
    }
}
