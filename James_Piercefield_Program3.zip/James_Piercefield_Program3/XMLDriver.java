/**
 * James Piercefield
 * - Driver
 * - Asks user for XML file, if the file is correctly formatted
 * - the user will then be given the option to write this to a different 
 * - XML file. 
 * - User can enter 'q' to exit the program.
 */
public class XMLDriver
{
    public static void main(String[] args) 
    {
        Context passVarXML = new Context();
        String XMLfile = Keyboard.readString("Enter the name of an XML file to read: ");
        String checkQuit = XMLfile.toLowerCase();
        if(!checkQuit.equals("q")) //q check
        {
            do{
                boolean testing = passVarXML.readFile(XMLfile);
                if(testing) 
                {
                    System.out.println("The file has been read successfully...");
                    XMLfile = Keyboard.readString("Enter the name of XML file to write: ");
                    checkQuit = XMLfile.toLowerCase();
                    if(checkQuit.equals("q")) //q check
                    {
                        break;
                    }
                    boolean secondTest = passVarXML.writeFile(XMLfile); //step into ---placer---
                    if(secondTest) 
                    {
                        System.out.println("The file has been written successfully...");
                    }else{
                        System.out.println("Sorry, the file was unsuccessfully written..."); //not
                    }
                }else{
                    System.out.println("Sorry, the file was unsuccessfully read..."); //not
                }
                XMLfile = Keyboard.readString("Enter the name of an XML file to read: ");
                checkQuit = XMLfile.toLowerCase(); 
            }while(!checkQuit.equals("q"));   
        }else{
            System.out.println("Error: File name cannot be: \"q\""); //chec q
        }
        
    }
}