/**
 * - James Piercefield
 * - Interface <br>
 * - Double "has-a" relationship <br>
 * - Changes Context's State <br>
 */
public interface stateInterface
{
	/**
	 * Precondition: Not <, /, " ", or > <br>
	 * - Only called when an unlisted character is read <br>
	 * - Returns true if input is allowed
	 */
	public boolean unlisted(char unknownChar);
	
	/**
	 * Precondition: " " Detected <br>
	 * - Returns true if input is allowed for the state instance
	 */
	public boolean space();
	
	/**
	 * Precondition: '/' Detected <br>
	 * - Returns true if input is allowed for the state instance
	 */
	public boolean forwardSlash();
	
	/**
	 * Precondition: '<' Detected <br>
	 * - Returns true if input is allowed for the state instance
	 */
	public boolean lessThan();
	
	/**
	 * Precondition: ">" Detected <br>
	 * - Returns true if input is allowed for the state instance
	 */
	public boolean greaterThan();
}