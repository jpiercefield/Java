import java.util.*;

/**
 * - James Piercefield
 * - Context/Controller, "has-a" w/States <br>
 * - Reads in XML file. <br>
 * - Outputs Correctly Formatted XML File <br>
 */
public class Context 
{
    private StartState startState;
    private BetweenTagState betweenTagState;
    private OpenTagState openTagState;
    private stateInterface rightNow;
    private CloseTagState closeTagState;
    private EndBetweenTagState endBetweenTagState;
    private DetectTagState detectTagState;
    private Stack<String> stackTag = new Stack<String>();
    private List<String> material = new ArrayList<String>();

    public Context() 
    {
        this.closeTagState = new CloseTagState(this);
        this.startState = new StartState(this);
        this.detectTagState = new DetectTagState(this);
        this.betweenTagState = new BetweenTagState(this);
        this.openTagState = new OpenTagState(this);
        this.endBetweenTagState = new EndBetweenTagState(this);
        this.rightNow = startState;
    }

    public StartState getStartState(){    return this.startState;}

    public DetectTagState getState(){    return this.detectTagState;}

    public OpenTagState getOpenTagState(){    return this.openTagState;}

    public CloseTagState getCloseTagState(){    return this.closeTagState;}

    public BetweenTagState getBetweenTagState(){    return this.betweenTagState;}

    public EndBetweenTagState getEndBetweenTagState(){    return this.endBetweenTagState;}

    /**
     * - Input/Output - Using Size
     */
    public Stack<String> getTags() 
    {
        return stackTag;
    }

    /**
     * - Used by the States <br>
     * - String for the individual lines 
     */
    public List<String> getWritingMaterial() 
    {
        return material; //check
    }

    /**
     * - Alternates the state to become the state passed in, the current state.
     */
    public void stateArrange(stateInterface state) 
    {
        this.rightNow = state; //<---
    }

    /**
     * Preconditions: A File Name
     * - Reads File, FileIO <br>
     * - Checks Formatting <br>
     * - Returns true if input is correctly formatted, <br>
     * - else returns false - Printing error and line number.
     */
    public boolean readFile(String fileName) 
    {
        int first = fileName.indexOf('?'); //check if file name conatain ? or :
        int second = fileName.indexOf(':');
        if(first == -1 && second == -1)
        {
            if(!material.isEmpty())
            {
                material.clear();
            }
            try {
                int numberOnL = 0;
                FileIO myFile = new FileIO(fileName, FileIO.FOR_READING);
                while(!myFile.EOF()) 
                {
                    String myVal = myFile.readLine(); //next
                    numberOnL++;
                    if (myVal == null) 
                    {
                        continue;
                    }
                    char unknownChar;
                    boolean completed;
                    for (int i = 0; i < myVal.length(); i++) 
                    {
                        unknownChar = myVal.charAt(i);
                        if(unknownChar == '<')
                        {
                            completed = rightNow.lessThan(); //step into
                        }
                        else if(unknownChar == '/')
                        {
                            completed = rightNow.forwardSlash();   
                        }
                        else if(unknownChar == '>')
                        {
                            completed = rightNow.greaterThan();
                        }
                        else if(Character.isSpaceChar(unknownChar))
                        {
                            completed = rightNow.space();
                        }
                        else
                        {
                            completed = rightNow.unlisted(unknownChar);
                        }
                        if (completed == false) 
                        {
                            System.out.println("ERROR: There was a problem on line " + numberOnL);
                            clearStack(); //--place
                            return completed;
                        }
                    }
                }
                myFile.close();
                if(!stackTag.isEmpty()) 
                {
                    System.out.println("ERROR: Could not find a closing tag at end of file, line: " + numberOnL);
                    clearStack(); //--place
                    return false;
                }
            }catch(FileIOException fioe){
                System.out.println(fioe.getMessage());
                clearStack(); //here
                return false;
            }
            clearStack(); 
            return true;
        }
        else{
            if(first != -1)
            {
                System.out.println("Your file name cannot contain a '?'");
            }
            else if(second != -1)
            {
                System.out.println("Your file name cannot contain a ':'");
            }
            return false;
        }
    }

    /**
     * - Sets the State as the Starting state. <br>
     * - Clears the stack.
     */
    private void clearStack() 
    {
        this.rightNow = getStartState();
        this.stackTag.clear(); //done
    }

    /**
     * Preconditions: File Name
     * - Vaildates String <br>
     * - Writes to file - FileIO (Proper Spacing Applied) <br>
     */
    public boolean writeFile(String fileName) 
    { 
        int first = fileName.indexOf('?');
        int second = fileName.indexOf(':');
        if(first == -1 && second == -1)
        {
            try {
                int length = fileName.length();
                if(length > 255) //fileNameLengthLimit
                {
                    return false;
                }
                FileIO myFile = new FileIO(fileName, FileIO.FOR_WRITING);//for_writing _reading
                Iterator<String> overAgain = material.iterator();
                while(overAgain.hasNext()){    myFile.writeLine(overAgain .next());}
                myFile.close();
            } catch (FileIOException fioe) 
            {
                return false;
            }
        }
        else
        {
            if(first != -1)
            {
                System.out.println("Your file name cannot contain a '?'");
            }
            else if(second != -1)
            {
                System.out.println("Your file name cannot contain a ':'");
            }
            return false;
        }
        return true;
    }
}