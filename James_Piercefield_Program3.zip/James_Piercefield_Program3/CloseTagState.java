/**
 * - XML State <br>
 * - Precondition: "/" @DecectTagState <br> 
 * - Takes ">" and any other character, besides "/", "<", " " <br>
 * - Proceeds to startState
 */
public class CloseTagState implements stateInterface 
{
    private String myTag;
    private Context passVarXML;
    public boolean lessThan(){    return false;} 
    public boolean forwardSlash(){    return false;}
    
    public boolean space()
    {
        myTag = new String("");
        return false;
    }
    
    public CloseTagState(Context fileVar) 
    {
        this.passVarXML = fileVar;
        this.myTag = "";
    }
       
    public boolean unlisted(char unknownChar) 
    {
        myTag += unknownChar;
        return true;
    }

    public boolean greaterThan() 
    {
        if(myTag.length() > 0) 
        {
            String startTag = passVarXML.getTags().pop();
            if(startTag.equals(myTag)) 
            {
                String spaceTabs = "";
                for(int i = 0; i < passVarXML.getTags().size(); i++) 
                {
                    spaceTabs += "    "; 
                }
                passVarXML.getWritingMaterial().add(spaceTabs + "</" + myTag + ">"); //this.
                passVarXML.stateArrange(passVarXML.getStartState());
                myTag = new String("");
                return true;
            }
            else
            {
                myTag = new String("");
                return false;    
            }
        }
        else
        {
            myTag = new String("");
            return false;
        }
    }

}