/**
 * - XML State <br>
 * - Precondition: Starting Tag, Tag Closed <br>
 * - Takes in "<", also accepts " "<br>
 */
public class StartState implements stateInterface 
{
    private Context passVarXML;
    public boolean greaterThan(){    return false;} 
    public boolean forwardSlash(){    return false;}
    public boolean space(){    return true;}
    
    public boolean unlisted(char unknownChar){
        return false;
    }
    
    public boolean lessThan() 
    {
        passVarXML.stateArrange(passVarXML.getState()); //-----placer---
        return true;
    }
    
    public StartState(Context fileVar) 
    {
        this.passVarXML = fileVar;
    }
}