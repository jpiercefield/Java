/**
 * - XML State <br>
 * - Precondition: New Tag <br>
 * - Takes in unknown character and ">", disallowed "/", "<", " " <br>
 * - Next State - BetweenTag
 */
public class OpenTagState implements stateInterface
{
    private Context passVarXML;
    private String myTag;
    public boolean lessThan(){    return false;} 
    public boolean forwardSlash(){    return false;}
    
    public OpenTagState(Context fileVar) 
    {
        this.passVarXML = fileVar;
        this.myTag = "";
    }
    
    public boolean space()
    {
        myTag = new String("");
        return false;
    }
 
    public boolean unlisted(char unknownChar) 
    {
        myTag += unknownChar;
        return true;
    }
    
    public boolean greaterThan() 
    {
        if(myTag.length() > 0) 
        {
            String spaceTabs = ""; 
            int index = 0;
            while(index < passVarXML.getTags().size())
            {
                spaceTabs += "    ";
                index++;
            }
            passVarXML.getWritingMaterial().add(spaceTabs + "<" + myTag + ">"); //"    "<ABC>
            passVarXML.getTags().push(myTag);
            myTag = new String("");
            passVarXML.stateArrange(passVarXML.getBetweenTagState());
            return true;
        }
        else
        {
            return false;
        }
    }

}