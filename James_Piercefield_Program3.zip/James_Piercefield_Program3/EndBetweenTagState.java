/**
 * - XML State <br>
 * - Reads in "/", Proceeds to CloseTagState <br>
 * - Else returns false. <br>
 * 
 */
public class EndBetweenTagState implements stateInterface 
{
    private Context passVarXML;
    public boolean greaterThan(){    return false;} 
    public boolean space(){    return false;}
    public boolean lessThan(){    return false;}

    public EndBetweenTagState(Context fileVar) 
    {
        this.passVarXML = fileVar;
    }

    public boolean unlisted(char unknownChar) 
    {
        return false;
    }
    
    public boolean forwardSlash() 
    {
        passVarXML.stateArrange(passVarXML.getCloseTagState());
        return true;
    }
}