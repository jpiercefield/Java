/**
 * - XML State <br>
 * - Precondition: Open Tag <br>
 * - Determine whether or not to open or close state <br>
 * - If "/" isn't recieved return false. <br>
 * - Next State - OpenTag or CloseTag
 */
public class DetectTagState implements stateInterface
{
    private Context passVarXML;
    public boolean greaterThan(){    return false;} 
    public boolean lessThan(){    return false;}
    public boolean space(){    return false;}
    
    public boolean unlisted(char unknownChar) 
    {
        OpenTagState state = passVarXML.getOpenTagState();
        passVarXML.stateArrange(state); 
        return state.unlisted(unknownChar);
    }

    public boolean forwardSlash() 
    {
        passVarXML.stateArrange(passVarXML.getCloseTagState());
        return true;
    }
    
    public DetectTagState(Context fileVar) 
    {
        this.passVarXML = fileVar;
    }
}