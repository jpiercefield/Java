public class BakedPotato extends BowlBase{
 
    public double cost(){
        return 1.99;
    }
    
    public String toString()
    {
        return super.toString()+"Baked Potato:\r\n";
    }
    
}
