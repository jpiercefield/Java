public class MixedGreen extends BowlBase{
    
    public double cost(){
        
        return 2.49;
    }
    
    public String toString(){
        
        return super.toString()+"Mixed Greens\r\n";
    }
}
