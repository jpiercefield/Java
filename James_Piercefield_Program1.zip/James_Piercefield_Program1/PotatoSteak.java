/**This is the bowl that I've created called the Potato Steak, which is a potaato with steak and edamame
   This class includes the contructor for PotatoSteak*/
public class PotatoSteak extends BowlBuilder
{
    // instance variables - replace the example below with your own
    //Constructor
    public PotatoSteak()
    {
        buildBase('P');
        buildProtein('S');
        buildTopping('E');
        
    }
    
}
